package com.example.spaceitup;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String answer1,answer4,answer7,answer10;
    int score=0;
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    private RadioButton answer2;
    private RadioButton answer5;
    private RadioButton answer9;
    private CheckBox answer3_checkbox1;
    private CheckBox answer3_checkbox2;
    private CheckBox answer3_checkbox3;
    private CheckBox answer3_checkbox4;
    private CheckBox answer6_checkbox1;
    private CheckBox answer6_checkbox2;
    private CheckBox answer6_checkbox3;
    private CheckBox answer6_checkbox4;
    private CheckBox answer8_checkbox1;
    private CheckBox answer8_checkbox2;
    private CheckBox answer8_checkbox3;
    private CheckBox answer8_checkbox4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=findViewById(R.id.EdtText1);
        editText2=findViewById(R.id.EdtText2);
        editText3=findViewById(R.id.EdtText3);
        editText4=findViewById(R.id.EdtText4);
        answer2=findViewById(R.id.answer2_radiobutton);
        answer5=findViewById(R.id.answer5_radiobutton);
        answer9=findViewById(R.id.answer9_radiobutton);
        answer3_checkbox1=findViewById(R.id.answer3_checkbox1);
        answer3_checkbox2=findViewById(R.id.answer3_checkbox2);
        answer3_checkbox3=findViewById(R.id.answer3_checkbox3);
        answer3_checkbox4=findViewById(R.id.answer3_checkbox4);
        answer6_checkbox1=findViewById(R.id.answer6_checkbox1);
        answer6_checkbox2=findViewById(R.id.answer6_checkbox2);
        answer6_checkbox3=findViewById(R.id.answer6_checkbox3);
        answer6_checkbox4=findViewById(R.id.answer6_checkbox4);
        answer8_checkbox1=findViewById(R.id.answer8_checkbox1);
        answer8_checkbox2=findViewById(R.id.answer8_checkbox2);
        answer8_checkbox3=findViewById(R.id.answer8_checkbox3);
        answer8_checkbox4=findViewById(R.id.answer8_checkbox4);

    }

    public void checking(View v){

        answer1=editText1.getText().toString();
        answer4=editText2.getText().toString();
        answer7=editText3.getText().toString();
        answer10=editText4.getText().toString();
        if(answer1.equalsIgnoreCase("mercury")){
            score++;
        }
        if(answer4.equalsIgnoreCase("blackhole"))
            score++;
        if(answer7.equalsIgnoreCase("mars"))
            score++;
        if(answer10.equalsIgnoreCase("uranus"))
            score++;

        if(answer2.isChecked())
            score++;
        if(answer5.isChecked())
            score++;
        if(answer9.isChecked())
            score++;
        if(!answer3_checkbox1.isChecked()&&answer3_checkbox2.isChecked()&&answer3_checkbox3.isChecked()&&answer3_checkbox4.isChecked())
            score++;
        if(answer6_checkbox1.isChecked()&&answer6_checkbox2.isChecked()&&!answer6_checkbox3.isChecked()&&!answer6_checkbox4.isChecked())
            score++;
        if(answer8_checkbox1.isChecked()&&answer8_checkbox4.isChecked()&&!answer8_checkbox2.isChecked()&&!answer8_checkbox3.isChecked())
            score++;
        if(score>=9)
        Toast.makeText(getApplicationContext(),"Total Score:"+score+"/10\n Excellent!",Toast.LENGTH_LONG).show();
        else if(score<=5) {
            Toast.makeText(getApplicationContext(),"Total Score:"+score+"/10\n Keep on improving!",Toast.LENGTH_LONG).show();
        } else
            Toast.makeText(getApplicationContext(),"Total Score:"+score+"/10\n Well Done!",Toast.LENGTH_LONG).show();
        score=0;
    }
}
